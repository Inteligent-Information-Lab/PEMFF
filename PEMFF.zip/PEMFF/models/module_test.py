import argparse
import contextlib
import os
import platform
import sys
from copy import deepcopy
from pathlib import Path


FILE = Path(__file__).resolve()
ROOT = FILE.parents[1]  # YOLOv5 root directory
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))  # add ROOT to PATH
if platform.system() != 'Windows':
    ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  # relative


from common import *  # noqa
from experimental import *  # noqa
from utils.autoanchor import check_anchor_order
from utils.general import LOGGER, check_version, check_yaml, make_divisible, print_args
from utils.plots import feature_visualization
from utils.torch_utils import (fuse_conv_and_bn, fuse_deconv_and_bn, initialize_weights, model_info, profile, scale_img, select_device,
                               time_sync)

from nn.modules.conv import RepConv
from nn.extra_modules import LAWDS, C3_ScConv, EMA, C3_DLKA, \
    RepBlock, REPEMA, RCSOSA, C3_Faster_EMA, C3_DBB, SPPF_LSKA, RepVGGBlock, PConv, C3_EMBC, C3_EMA, C3_Faster
from nn.extra_modules.head import *
from nn.extra_modules.attention import CoordAtt
from Biformer import BiLevelRoutingAttention, Attention, AttentionLePE



    
    
if __name__ == '__main__':
    conv3 = PConv(64, 2, 'split_cat', 3)
    conv1 = PConv(64, 2, 'split_cat', 1)
    x = torch.randn(1, 64, 256, 256)
    y1 = conv3(x)
    y2 = conv1(x)
    print(y1.shape)
    print(y2.shape)